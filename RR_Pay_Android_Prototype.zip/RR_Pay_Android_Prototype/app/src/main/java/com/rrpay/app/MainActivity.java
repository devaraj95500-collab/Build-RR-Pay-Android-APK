package com.rrpay.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int purple = Color.rgb(82, 43, 202);
    private final int dark = Color.rgb(32, 28, 45);
    private final int muted = Color.rgb(111, 108, 125);
    private final int pale = Color.rgb(246, 243, 255);
    private LinearLayout root;
    private String page = "Home";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(purple);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        showPage("Home");
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setFontFeatureSettings("kern");
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(l,t,r,b); }
    private void space(LinearLayout parent, int height) { View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1,height)); }
    private void card(LinearLayout parent, View child) {
        child.setBackground(bg(Color.WHITE, 28)); pad(child, 18, 16, 18, 16);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 12; parent.addView(child,p);
    }
    private Button button(String label, boolean primary, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.WHITE : purple); b.setBackground(bg(primary ? purple : pale, 22));
        b.setMinHeight(52); b.setOnClickListener(v -> action.run()); return b;
    }
    private void showPage(String which) {
        page = which;
        root = column(); root.setBackgroundColor(Color.rgb(249,248,252));
        setContentView(root);
        LinearLayout header = column(); header.setBackgroundColor(purple); pad(header,22,14,22,22);
        LinearLayout top = row();
        TextView logo = text("◈  RR Pay", 23, Color.WHITE, true); top.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
        TextView profile = text("●", 24, Color.WHITE, true); profile.setGravity(Gravity.CENTER); top.addView(profile,new LinearLayout.LayoutParams(42,42));
        header.addView(top);
        TextView subtitle = text("Simple. Secure. Smarter payments.", 13, Color.rgb(231,224,255), false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=8; header.addView(subtitle,sp);
        root.addView(header);
        ScrollView scroll = new ScrollView(this); LinearLayout content = column(); pad(content,18,18,18,18); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if (which.equals("Home")) home(content);
        else if (which.equals("Scan & Pay")) scan(content);
        else if (which.equals("History")) history(content);
        else profilePage(content);
        bottomNav();
    }
    private void home(LinearLayout c) {
        LinearLayout notice = column(); notice.setBackground(bg(Color.rgb(255,247,224),22)); pad(notice,16,14,16,14);
        notice.addView(text("PROTOTYPE MODE",12,Color.rgb(135,83,0),true));
        space(notice,4); notice.addView(text("Real UPI payments are not enabled. Bank/NPCI approval and certified integration are required.",13,Color.rgb(112,75,13),false)); card(c,notice);
        LinearLayout welcome = column(); welcome.addView(text("Welcome to RR Pay",23,dark,true)); space(welcome,5); welcome.addView(text("Your everyday payments, in one place.",14,muted,false)); card(c,welcome);
        LinearLayout quick = row();
        quick.addView(button("▦  Scan QR",true,()->showPage("Scan & Pay")),new LinearLayout.LayoutParams(0,54,1));
        View gap = new View(this); quick.addView(gap,new LinearLayout.LayoutParams(10,1));
        quick.addView(button("↗  Pay",false,()->demo("Payment")),new LinearLayout.LayoutParams(0,54,1)); c.addView(quick); space(c,14);
        LinearLayout services = column(); services.addView(text("Explore",18,dark,true)); space(services,10);
        addService(services,"▦","Scan any QR","Demo screen only",()->showPage("Scan & Pay"));
        addService(services,"↔","Send money","Available after approved UPI integration",()->demo("Send Money"));
        addService(services,"▤","Transaction history","View prototype entries",()->showPage("History"));
        card(c,services);
        LinearLayout safe=column(); safe.addView(text("Stay safe",17,dark,true)); space(safe,7); safe.addView(text("Never share your UPI PIN or OTP. RR Pay prototype will never ask for them.",14,muted,false)); card(c,safe);
    }
    private void addService(LinearLayout parent,String icon,String title,String desc,Runnable action) {
        LinearLayout r=row(); TextView ic=text(icon,22,purple,true); ic.setGravity(Gravity.CENTER); ic.setBackground(bg(pale,16)); r.addView(ic,new LinearLayout.LayoutParams(48,48));
        LinearLayout labels=column(); pad(labels,12,0,0,0); labels.addView(text(title,15,dark,true)); labels.addView(text(desc,12,muted,false)); r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("›",27,muted,false); r.addView(arrow); r.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=12; parent.addView(r,p);
    }
    private void scan(LinearLayout c) {
        LinearLayout intro=column(); intro.addView(text("Scan & Pay",24,dark,true)); space(intro,5); intro.addView(text("QR scanning is a placeholder in this prototype.",14,muted,false)); card(c,intro);
        LinearLayout qr=column(); qr.setGravity(Gravity.CENTER); qr.setBackground(bg(Color.WHITE,28)); pad(qr,24,32,24,32);
        TextView symbol=text("▦",92,purple,true); symbol.setGravity(Gravity.CENTER); qr.addView(symbol,new LinearLayout.LayoutParams(-1,130));
        TextView t=text("QR Scanner",20,dark,true); t.setGravity(Gravity.CENTER); qr.addView(t);
        TextView d=text("Camera scanning will be added after choosing an approved QR/UPI integration.",14,muted,false); d.setGravity(Gravity.CENTER); pad(d,0,8,0,12); qr.addView(d); qr.addView(button("Continue in Demo",true,()->demo("QR Scan"))); card(c,qr);
        c.addView(button("Back to Home",false,()->showPage("Home")));
    }
    private void history(LinearLayout c) {
        c.addView(text("Transaction History",23,dark,true)); space(c,8);
        LinearLayout info=column(); info.addView(text("No real transactions yet",17,dark,true)); space(info,6); info.addView(text("This demo does not connect to a bank or UPI network. Any sample entry is not proof of payment.",14,muted,false)); card(c,info);
        addService(c,"✓","Prototype opened","No money moved",()->{});
        c.addView(button("Back to Home",true,()->showPage("Home")));
    }
    private void profilePage(LinearLayout c) {
        c.addView(text("Profile & Settings",23,dark,true)); space(c,12);
        LinearLayout p=column(); p.addView(text("RR Pay Prototype",18,dark,true)); space(p,8); p.addView(text("Version 0.1.0 · Android",14,muted,false)); space(p,8); p.addView(text("Status: Demo only — no bank account linked.",14,muted,false)); card(c,p);
        LinearLayout s=column(); s.addView(text("Security",17,dark,true)); space(s,7); s.addView(text("• Never enter or share UPI PIN in this app prototype.\n• Do not share OTPs.\n• Payment status must be verified by the authorized bank/UPI system.\n• This app is not affiliated with PhonePe.",14,muted,false)); card(c,s);
    }
    private void demo(String feature) { Toast.makeText(this, feature+" is demo-only. Real UPI is not enabled.", Toast.LENGTH_LONG).show(); }
    private void bottomNav() {
        LinearLayout nav=row(); nav.setBackgroundColor(Color.WHITE); pad(nav,8,8,8,8);
        String[] labels={"Home","Scan & Pay","History","Profile"}; String[] icons={"⌂","▦","▤","●"};
        for(int i=0;i<labels.length;i++) {
            final String label=labels[i]; LinearLayout item=column(); item.setGravity(Gravity.CENTER);
            TextView ic=text(icons[i],20,label.equals(page)?purple:muted,true); ic.setGravity(Gravity.CENTER); item.addView(ic);
            TextView tx=text(label,11,label.equals(page)?purple:muted,label.equals(page)); tx.setGravity(Gravity.CENTER); item.addView(tx);
            item.setOnClickListener(v->showPage(label)); nav.addView(item,new LinearLayout.LayoutParams(0,54,1));
        }
        root.addView(nav);
    }
}
