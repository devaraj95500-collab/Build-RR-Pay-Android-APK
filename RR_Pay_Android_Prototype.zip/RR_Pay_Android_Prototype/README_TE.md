# RR Pay Android Prototype (v0.1.0)

ఇది RR Pay కోసం రూపొందించిన Android Studio project. ఇది UI prototype మాత్రమే.

## ప్రస్తుతం ఉన్నవి
- RR Pay home screen
- Scan & Pay placeholder screen
- Transaction History demo screen
- Profile & safety guidance
- Bottom navigation
- Real payments లేవు; bank account linking/UPI PIN/real QR scanning అమలు చేయలేదు.

## కంప్యూటర్‌లో APK build చేయడం
1. Android Studioని అధికారిక Android Developers వెబ్‌సైట్ నుంచి install చేయండి.
2. ఈ ZIPని extract చేయండి.
3. Android Studioలో `RR_Pay_Android_Prototype` ఫోల్డర్‌ను Open చేయండి.
4. Gradle sync పూర్తయ్యే వరకు వేచి ఉండండి. అవసరమైతే Android SDK Platform 35, Android Gradle Plugin/Gradle components install చేయండి.
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)` ఎంచుకోండి.
6. Build విజయవంతమైతే Android Studio APK location చూపిస్తుంది. සාමාන්‍යமாக `app/build/outputs/apk/debug/app-debug.apk` వద్ద ఉంటుంది.
7. APKని మీ Android ఫోన్‌కు కాపీ చేసి install చేయండి. ఫోన్‌లో అవసరమైతే ఈ ఫైల్‌కు మాత్రమే “Install unknown apps” అనుమతి ఇవ్వండి; install తర్వాత ఆ అనుమతిని నిలిపివేయండి.

## ముఖ్యమైన పరిమితులు
- ఈ projectలో నిజమైన UPI transfer, bank linking, QR scanning, merchant checkout, production backend లేదా database లేదు.
- NPCI/Sponsor PSP Bank approvals, applicable certification/security audits మరియు authorized integration లేకుండా నిజమైన UPI appగా విడుదల చేయకండి.
- UPI PIN/OTP ఎప్పుడూ ఈ prototypeలో అడగకండి లేదా నిల్వ చేయకండి.
- ఈ prototype PhonePeతో అనుబంధం కలిగినది కాదు; PhonePe branding/assets ఉపయోగించదు.

## Build requirements
- Android Studio (current stable)
- JDK 17 compatible with Android Gradle Plugin 8.6.1
- Android SDK Platform 35
- Internet access for first Gradle sync
