# Security and compliance notes

This project is a visual prototype only. No payment SDK or banking credentials are included.

Before a real UPI launch:
1. Obtain written onboarding guidance/approval from a Sponsor PSP Bank and satisfy applicable NPCI requirements.
2. Use only bank/NPCI-authorized SDKs and integration specifications supplied to the approved participant.
3. Keep secrets server-side; never embed API secrets in the APK.
4. Never collect or store UPI PINs or OTPs.
5. Verify payment status through the authorized server-side flow; do not trust client UI or screenshots.
6. Add threat modeling, secure storage, tamper/root risk assessment as required, rate limits, fraud monitoring, audit trails, dispute handling, privacy/data-retention controls, penetration testing and applicable certifications.
7. Do not mark a transaction successful until the authoritative payment system confirms it.
